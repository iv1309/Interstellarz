package com.movies.moviesapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviesApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
